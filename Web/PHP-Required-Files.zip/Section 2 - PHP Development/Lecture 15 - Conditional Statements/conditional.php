<!DOCTYPE html>
<html>
<body>

<?php

#IF STATEMENT
$x = 49;

if ($x < 50) {
     echo "Condition Met";
}

?>
  
</body>
</html>