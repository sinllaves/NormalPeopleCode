<!DOCTYPE html>
<html>
<body>

<?php

$x = 90;

if ($x < 50) {	
		 echo "F";
	} else if ($x >=  50 && $x <  60) {
		echo "D";
	} else if ($x >=  60 && $x <  70) {
		echo "C";
	} else if ($x >=  70 && $x <  80) {
		echo "B";
	} else if ($x >=  80 && $x <  90) {
		echo "A";
	} else {
		echo "A+";
}


?>
  
</body>
</html>