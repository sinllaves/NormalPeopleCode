<!DOCTYPE html>
<html>
<body>

<?php
//BASIC FUNCTION
function displaytxt() {
     echo "My First Function";
}

displaytxt();

echo "<hr />";

//FUNCTION ARGUMENTS
function myCar($car) {
    echo "$car<br>";
}

myCar("Volvo");
myCar("BMW");
myCar("Honda");

?>



</body>
</html>